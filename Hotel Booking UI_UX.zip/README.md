
  # Hotel Booking UI/UX

  This is a code bundle for Hotel Booking UI/UX. The original project is available at https://www.figma.com/design/VVWlTew7dJbq9eD7XPHkJi/Hotel-Booking-UI-UX.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  